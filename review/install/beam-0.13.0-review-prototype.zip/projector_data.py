import bpy
from bpy.props import (BoolProperty, IntProperty, FloatProperty, FloatVectorProperty,
                       StringProperty, EnumProperty, PointerProperty)


def changed(self, context):
    from . import runtime
    runtime.invalidate(self.id_data)
    from . import analysis_runtime
    analysis_runtime.invalidate()


def photometry_changed(self,context):
    from . import runtime,analysis_runtime
    runtime.invalidate(self.id_data);analysis_runtime.invalidate('ILLUMINANCE')


def appearance_changed(self,context):
    from . import runtime
    runtime.invalidate(self.id_data)


from . import optics_library

def optics_changed(self,context):
    self.optics_lens='MANUAL'
    changed(self,context)

class PS_Settings(bpy.types.PropertyGroup):
    optics_model: EnumProperty(name='Projector Preset',items=optics_library.projector_items(),default='MANUAL',update=optics_changed)
    optics_lens: EnumProperty(name='Lens',items=optics_library.lens_items,update=changed)
    data_version: IntProperty(default=0,options={'HIDDEN'})
    is_projector: BoolProperty(default=False)
    identifier: StringProperty()
    uuid: StringProperty()
    solve_by: EnumProperty(name='Solve By',items=[('LENS','Lens / Throw Ratio','Keep position fixed'),('POSITION','Projector Position','Keep ratio and centre target fixed'),('AUTO','Both / Auto','Prefer lens; use position for distance or a locked lens')],default='LENS')
    solve_lock_position: BoolProperty(name='Lock Position',description='Prevent solved targets from moving this projector',default=False)
    solve_lock_lens: BoolProperty(name='Lock Throw Ratio',description='Keep the lens ratio fixed during target solves',default=False)
    solve_lock_target: BoolProperty(name='Lock Target',description='Reject a solve that changes the centre target position',default=True)
    notes: StringProperty(name='Notes',description='Projector notes included in JSON interchange')
    active: BoolProperty(name='Include in Export', default=True, update=changed)
    resolution_x: IntProperty(name='Resolution X', default=1920, min=1, max=32768, update=changed)
    resolution_y: IntProperty(name='Resolution Y', default=1080, min=1, max=32768, update=changed)
    throw_ratio: FloatProperty(name='Throw Ratio', default=1.0, min=0.05, max=100, update=changed)
    shift_h: FloatProperty(name='Horizontal Shift %', precision=1, description='Image-centre offset as percent of full image width; positive right', default=0, min=-300, max=300, update=changed)
    shift_v: FloatProperty(name='Vertical Shift %', precision=1, description='Image-centre offset as percent of full image height; positive up', default=0, min=-300, max=300, update=changed)
    stack: IntProperty(name='Stack Quantity', default=1, min=1, update=photometry_changed)
    brightness: FloatProperty(name='Brightness %', precision=1, default=100, min=0, max=100, update=photometry_changed)
    lumens: FloatProperty(name='Nominal Lumens', precision=0, default=20000, min=0, update=photometry_changed)
    colour: FloatVectorProperty(name='Study Colour', subtype='COLOR', size=3, min=0, max=1, default=(0.77, 0.39, 0.36), update=appearance_changed)
    # Explicit enum numbers preserve modes saved by versions 0.1–0.3.
    output_mode: EnumProperty(name='Output Mode',items=[
        ('SOLID','Solid Colour','',0,0),('GRID','Calibration Grid','',0,1),
        ('ID','Identifier','',0,2),('CHECKER','Checkerboard','',0,3),
        ('UV_GRID','Blender UV Grid','',0,4),('COLOR_GRID','Blender Color Grid','',0,6),
        ('IMAGE','Custom Image','',0,5)],default='GRID',update=changed)

    image: PointerProperty(name='Custom Image', type=bpy.types.Image, update=appearance_changed)
    show_grid: BoolProperty(name='Show Grid', default=True, update=appearance_changed)
    show_projected_identifier: BoolProperty(name='Projected Name',default=True,update=appearance_changed)
    show_identifier: BoolProperty(name='Body / Measurement Labels', description='Show this projector’s body ID and measurement labels', default=True, update=appearance_changed)
    show_frustum: BoolProperty(name='Show Frustum', description='Show this projector’s viewport cone helper', default=True, update=appearance_changed)
    show_target_marker: BoolProperty(name='Target Marker',default=True,update=appearance_changed)
    show_centre_ray: BoolProperty(name='Centre Ray',default=True,update=appearance_changed)
    show_output: BoolProperty(name='Show Projected Output', default=True, update=appearance_changed)
    target: PointerProperty(name='Automatic Target', type=bpy.types.Object, description='Computed first centre-raster hit; never a receiver filter')
    has_target: BoolProperty(default=False,options={'HIDDEN'})
    target_point_m: FloatVectorProperty(size=3,options={'HIDDEN'})
    target_distance_m: FloatProperty(options={'HIDDEN'})
    preview_distance: FloatProperty(name='No-hit Preview (m)', default=10, min=0.01, update=appearance_changed)
